// options.js

// 初期表示：保存済み設定をチェックボックスに反映
window.addEventListener('DOMContentLoaded', () => {
  chrome.storage.sync.get({ selected: ['chat', 'gemini', 'grok', 'perplexity'] }, ({ selected }) => {
    selected.forEach(key => {
      const cb = document.querySelector(`input[name=target][value=${key}]`);
      if (cb) cb.checked = true;
    });
  });

  // チェックボックス変更時に即時保存＆トースト表示
  const checkboxes = document.querySelectorAll('input[name=target]');
  checkboxes.forEach(cb => {
    cb.addEventListener('change', () => {
      const selected = Array.from(
        document.querySelectorAll('input[name=target]:checked')
      ).map(el => el.value);
      chrome.storage.sync.set({ selected }, () => {
        showToast('設定を更新しました');
      });
    });
  });
});

// トースト表示用関数
function showToast(message) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add('show');
  setTimeout(() => {
    toast.classList.remove('show');
  }, 2000);
}

// デフォルトのプロンプトテンプレート
const DEFAULT_PROMPTS = {
  'send-text': `以下のURLを読み込んでください。
{pageUrl}

そこに記載されている「{selectionText}」について、一般的な意味合いだけでなく、文章内でどのような意味で使われているか、教えてください。`,

  'send-url': `以下のURLを読み込んでください。
{pageUrl}

記事の内容を以下の見やすいMarkdown形式でまとめてください。
1. **わかりやすい要約**
2. **特徴的なキーワードの解説**
3. **記事を理解するために知っておくべき補足情報**`,

  'translate-text': `次のテキストを翻訳してください。英語なら日本語、日本語なら英語。その他の言語なら日本語に。

翻訳結果を提示する際には、上級レベルの英語学習者にとって役立つ追加情報（語彙のニュアンス、例文、語法のポイントなど）をできるだけ詳しく説明してください。
{selectionText}`
};

// 設定の保存
function saveOptions() {
  const selected = Array.from(document.querySelectorAll('input[name="service"]:checked'))
    .map(checkbox => checkbox.value);

  const prompts = {
    'send-text': document.getElementById('send-text-prompt').value.trim() || DEFAULT_PROMPTS['send-text'],
    'send-url': document.getElementById('send-url-prompt').value.trim() || DEFAULT_PROMPTS['send-url'],
    'translate-text': document.getElementById('translate-text-prompt').value.trim() || DEFAULT_PROMPTS['translate-text']
  };

  // 空のプロンプトをデフォルト値で上書き
  Object.keys(prompts).forEach(key => {
    if (!prompts[key]) {
      prompts[key] = DEFAULT_PROMPTS[key];
      document.getElementById(`${key}-prompt`).value = DEFAULT_PROMPTS[key];
    }
  });

  chrome.storage.sync.set(
    { 
      selected,
      prompts
    },
    () => {
      const saveButton = document.getElementById('save');
      const originalText = saveButton.textContent;
      saveButton.textContent = '保存しました！';
      saveButton.disabled = true;
      setTimeout(() => {
        saveButton.textContent = originalText;
        saveButton.disabled = false;
      }, 1500);
    }
  );
}

// 設定の読み込み
function restoreOptions() {
  chrome.storage.sync.get(
    { 
      selected: ['chat', 'gemini', 'grok', 'perplexity'],
      prompts: DEFAULT_PROMPTS
    },
    (items) => {
      // サービスの選択状態を復元
      items.selected.forEach(value => {
        const checkbox = document.querySelector(`input[name="service"][value="${value}"]`);
        if (checkbox) checkbox.checked = true;
      });

      // プロンプトの内容を復元（空の場合はデフォルト値を使用）
      Object.keys(DEFAULT_PROMPTS).forEach(key => {
        const value = items.prompts[key]?.trim() || DEFAULT_PROMPTS[key];
        document.getElementById(`${key}-prompt`).value = value;
      });
    }
  );
}

// デフォルト設定に戻す
function resetOptions() {
  // サービスをすべて選択
  document.querySelectorAll('input[name="service"]').forEach(checkbox => {
    checkbox.checked = true;
  });

  // プロンプトをデフォルトに戻す
  document.getElementById('send-text-prompt').value = DEFAULT_PROMPTS['send-text'];
  document.getElementById('send-url-prompt').value = DEFAULT_PROMPTS['send-url'];
  document.getElementById('translate-text-prompt').value = DEFAULT_PROMPTS['translate-text'];

  // 保存
  saveOptions();
}

// イベントリスナーの設定
document.addEventListener('DOMContentLoaded', restoreOptions);
document.getElementById('save').addEventListener('click', saveOptions);
document.getElementById('reset').addEventListener('click', resetOptions);