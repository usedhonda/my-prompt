// background.js

// デフォルトのプロンプトテンプレート
const DEFAULT_PROMPTS = {
  'send-url': `以下のURLを読み込んでください。
{pageUrl}

記事の内容を以下の見やすいMarkdown形式でまとめてください。
1. **わかりやすい要約**
2. **特徴的なキーワードの解説**
3. **記事を理解するために知っておくべき補足情報**`,

  'send-text': `以下のURLを読み込んでください。
{pageUrl}

そこに記載されている「{selectionText}」について、一般的な意味合いだけでなく、文章内でどのような意味で使われているか、教えてください。`,

  'translate-text': `次のテキストを翻訳してください。英語なら日本語、日本語なら英語。その他の言語なら日本語に。

翻訳結果を提示する際には、上級レベルの英語学習者にとって役立つ追加情報（語彙のニュアンス、例文、語法のポイントなど）をできるだけ詳しく説明してください。
{selectionText}`
};

// コンテキストメニューの設定
const CONTEXT_MENUS = [
  {
    id: 'send-url',
    title: '送信: ページのURL',
    contexts: ['all']
  },
  {
    id: 'send-text',
    title: '送信: 選択テキスト',
    contexts: ['selection']
  },
  {
    id: 'translate-text',
    title: '翻訳: 選択テキスト',
    contexts: ['selection']
  }
];

// コンテキストメニューの登録
chrome.runtime.onInstalled.addListener(() => {
  // 既存のメニューをクリア
  chrome.contextMenus.removeAll(() => {
    // メニューを順番に作成
    CONTEXT_MENUS.forEach(menu => {
      chrome.contextMenus.create(menu);
    });
  });
});

// メニュークリック処理
chrome.contextMenus.onClicked.addListener(info => {
  chrome.storage.sync.get(
    { 
      selected: ['chat', 'gemini', 'grok', 'perplexity'],
      prompts: DEFAULT_PROMPTS
    },
    ({ selected, prompts }) => {
      // プロンプトテンプレートの変数を置換
      let payload = prompts[info.menuItemId]?.trim() || DEFAULT_PROMPTS[info.menuItemId];
      payload = payload.replace(/{pageUrl}/g, info.pageUrl || '')
                      .replace(/{selectionText}/g, info.selectionText || '');

      // 各サービスに送信
      selected.forEach(serviceKey => {
        if (serviceKey === 'perplexity') {
          // Perplexity はクエリ文字列で直接検索
          const url = 'https://www.perplexity.ai/search?q=' + encodeURIComponent(payload);
          chrome.tabs.create({ url, active: false });
        } else {
          const serviceMap = {
            chat:   'https://chat.openai.com/chat',
            gemini: 'https://gemini.google.com/app',
            grok:   'https://x.com/i/grok'
          };
          const targetUrl = serviceMap[serviceKey];
          if (!targetUrl) return;

          chrome.tabs.create({ url: targetUrl, active: false }, tab => {
            const onUpdated = (tabId, changeInfo) => {
              if (tabId === tab.id && changeInfo.status === 'complete') {
                chrome.tabs.onUpdated.removeListener(onUpdated);
                chrome.scripting.executeScript({
                  target: { tabId: tab.id },
                  func: (text) => {
                    const host = location.host;
                    // ChatGPT
                    if (host.includes('chat.openai.com') || host.includes('chatgpt.com')) {
                      const waitPrompt = () => {
                        const pm = document.getElementById('prompt-textarea');
                        if (!pm) return setTimeout(waitPrompt, 600);
                        pm.focus(); pm.innerHTML = '';
                        document.execCommand('insertText', false, text);
                        pm.dispatchEvent(new InputEvent('input', { bubbles: true }));
                        waitSend();
                      };
                      const waitSend = () => {
                        const btn = document.getElementById('composer-submit-button') ||
                                    document.querySelector('[data-testid="send-button"]');
                        if (!btn) return setTimeout(waitSend, 600);
                        btn.click();
                      };
                      setTimeout(waitPrompt, 1000);
                    }
                    // Gemini
                    else if (host.includes('gemini.google.com')) {
                      const waitGemini = () => {
                        // より具体的なセレクタを使用
                        const inputEl = document.querySelector('[role="textbox"], textarea');
                        const sendBtn = document.querySelector('button[aria-label*="送信"], button[aria-label*="Send"]');
                        
                        if (!inputEl || !sendBtn) return setTimeout(waitGemini, 600);
                        
                        // テキストの入力
                        inputEl.focus();
                        if (inputEl.tagName.toLowerCase() === 'textarea') {
                          inputEl.value = text;
                        } else {
                          inputEl.textContent = text;
                        }
                        inputEl.dispatchEvent(new InputEvent('input', { bubbles: true }));
                        
                        // 少し待ってから送信（入力が確実に反映されるのを待つ）
                        setTimeout(() => {
                          if (!sendBtn.disabled) {
                            sendBtn.click();
                          }
                        }, 500);
                      };
                      setTimeout(waitGemini, 800);
                    }
                    // Grok
                    else if (host.includes('x.com')) {
                      const waitGrok = () => {
                        // 日本語と英語の両方に対応したセレクタ
                        const inputEl = document.querySelector('textarea[placeholder*="どんなことでも"], textarea[placeholder*="Ask"]');
                        const sendBtn = document.querySelector('button[aria-label*="Grokに聞く"], button[aria-label*="Ask Grok"]');
                        
                        if (!inputEl || !sendBtn) return setTimeout(waitGrok, 600);
                        
                        // テキストの入力
                        inputEl.focus();
                        inputEl.value = text;
                        inputEl.dispatchEvent(new InputEvent('input', { bubbles: true }));
                        
                        // 送信ボタンが有効な場合のみクリック
                        if (!sendBtn.disabled) {
                          sendBtn.click();
                        }
                      };
                      setTimeout(waitGrok, 800);
                    }
                  },
                  args: [payload]
                });
              }
            };
            chrome.tabs.onUpdated.addListener(onUpdated);
          });
        }
      });
    }
  );
});